import { Request, Response } from 'express';
import * as service from './watchlist.service';
import { sendSuccess, sendError, sendNoContent } from '../../utils/response';

export async function add(req: Request, res: Response) {
  const buyerId = req.buyer?.id;
  const vehicleId = Number(req.body.vehicle_id || req.params.vehicleId);
  if (!buyerId || Number.isNaN(vehicleId)) {
    return sendError(res, 'Invalid buyer or vehicle id');
  }
  await service.add(buyerId, vehicleId);
  return sendNoContent(res, 'Vehicle added to watchlist successfully');
}

export async function list(req: Request, res: Response) {
  const buyerId = req.buyer?.id;
  const limit = Number(req.query.limit ?? 50);
  const offset = Number(req.query.offset ?? 0);
  if (!buyerId) {
    return sendError(res, 'Invalid buyer');
  }
  const items = await service.list(buyerId, limit, offset);
  return sendSuccess(res, 'Watchlist retrieved successfully', items);
}

export async function toggle(req: Request, res: Response) {
  const buyerId = req.buyer?.id;
  const vehicleId = Number(req.body.vehicle_id || req.params.vehicleId);
  if (!buyerId || Number.isNaN(vehicleId)) {
    return sendError(res, 'Invalid buyer or vehicle id');
  }
  const result = await service.toggle(buyerId, vehicleId);
  return sendSuccess(res, 'Watchlist toggle completed successfully', result);
}


