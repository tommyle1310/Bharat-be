# Response Utility

This utility provides standardized API response functions for consistent frontend integration.

## Response Format

All API responses follow this standardized format:

```typescript
{
  message: string;    // Human-readable message
  code: number;       // HTTP status code
  data: any;          // Response data (optional)
}
```

## Available Functions

### Core Function
- `sendResponse(res, status, message, data?)` - Main function for custom responses

### Helper Functions
- `sendSuccess(res, message?, data?)` - 200 status
- `sendError(res, message?, data?)` - 400 status  
- `sendNotFound(res, message?, data?)` - 404 status
- `sendUnauthorized(res, message?, data?)` - 401 status
- `sendForbidden(res, message?, data?)` - 403 status
- `sendInternalError(res, message?, data?)` - 500 status
- `sendCreated(res, message?, data?)` - 201 status
- `sendNoContent(res, message?, data?)` - 204 status

## Usage Examples

```typescript
import { sendSuccess, sendError, sendNotFound } from '../../utils/response';

// Success response
return sendSuccess(res, 'Data retrieved successfully', data);

// Error response
return sendError(res, 'Invalid input parameters');

// Not found response
return sendNotFound(res, 'Resource not found');

// Custom status
return sendResponse(res, 422, 'Validation failed', { errors: [...] });
```

## Frontend Integration

The frontend can now consistently handle responses by checking the `code` field:

```javascript
// Example frontend handling
fetch('/api/vehicles')
  .then(response => response.json())
  .then(data => {
    if (data.code === 200) {
      // Success - use data.data
      console.log('Success:', data.message);
      displayVehicles(data.data);
    } else if (data.code === 400) {
      // Error - show data.message
      showError(data.message);
    } else if (data.code === 404) {
      // Not found - show data.message
      showNotFound(data.message);
    }
  });
```

## Benefits

1. **Consistency**: All API responses follow the same format
2. **Frontend-Friendly**: Easy to map status codes to UI actions
3. **Maintainable**: Centralized response handling
4. **Type-Safe**: TypeScript interfaces ensure proper usage
5. **Extensible**: Easy to add new response types
