import { Response } from 'express';

export interface ApiResponse {
  message: string;
  code: number;
  data: any;
}

/**
 * Standardized API response utility function
 * @param res - Express Response object
 * @param status - HTTP status code (200, 400, 404, 500, etc.)
 * @param message - Response message
 * @param data - Response data (optional)
 * @returns Express Response with standardized format
 */
export function sendResponse(
  res: Response,
  status: number,
  message: string,
  data: any = null
): Response {
  const response: ApiResponse = {
    message,
    code: status,
    data
  };
  
  return res.status(status).json(response);
}

/**
 * Success response helper (200 status)
 * @param res - Express Response object
 * @param message - Success message
 * @param data - Response data (optional)
 */
export function sendSuccess(
  res: Response,
  message: string = 'Success',
  data: any = null
): Response {
  return sendResponse(res, 200, message, data);
}

/**
 * Error response helper (400 status)
 * @param res - Express Response object
 * @param message - Error message
 * @param data - Additional error data (optional)
 */
export function sendError(
  res: Response,
  message: string = 'Bad Request',
  data: any = null
): Response {
  return sendResponse(res, 400, message, data);
}

/**
 * Not found response helper (404 status)
 * @param res - Express Response object
 * @param message - Not found message
 * @param data - Additional data (optional)
 */
export function sendNotFound(
  res: Response,
  message: string = 'Not Found',
  data: any = null
): Response {
  return sendResponse(res, 404, message, data);
}

/**
 * Unauthorized response helper (401 status)
 * @param res - Express Response object
 * @param message - Unauthorized message
 * @param data - Additional data (optional)
 */
export function sendUnauthorized(
  res: Response,
  message: string = 'Unauthorized',
  data: any = null
): Response {
  return sendResponse(res, 401, message, data);
}

/**
 * Forbidden response helper (403 status)
 * @param res - Express Response object
 * @param message - Forbidden message
 * @param data - Additional data (optional)
 */
export function sendForbidden(
  res: Response,
  message: string = 'Forbidden',
  data: any = null
): Response {
  return sendResponse(res, 403, message, data);
}

/**
 * Internal server error response helper (500 status)
 * @param res - Express Response object
 * @param message - Error message
 * @param data - Additional error data (optional)
 */
export function sendInternalError(
  res: Response,
  message: string = 'Internal Server Error',
  data: any = null
): Response {
  return sendResponse(res, 500, message, data);
}

/**
 * Created response helper (201 status)
 * @param res - Express Response object
 * @param message - Created message
 * @param data - Response data (optional)
 */
export function sendCreated(
  res: Response,
  message: string = 'Created',
  data: any = null
): Response {
  return sendResponse(res, 201, message, data);
}

/**
 * No content response helper (204 status)
 * @param res - Express Response object
 * @param message - No content message
 * @param data - Additional data (optional)
 */
export function sendNoContent(
  res: Response,
  message: string = 'No Content',
  data: any = null
): Response {
  return sendResponse(res, 204, message, data);
}
